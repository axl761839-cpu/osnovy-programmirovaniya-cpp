﻿#include <iostream>
using namespace std;

int main()
{
    int distance = 1000;
    int minutes = 3;
    int seconds = 25;

    int totalSeconds = minutes * 60 + seconds;

    double speed = (distance / 1000.0) / (totalSeconds / 3600.0);

    cout << "Calculating running speed." << endl;
    cout << "Distance: " << distance << " meters" << endl;
    cout << "Time: " << minutes << " min " << seconds << " sec = "
         << totalSeconds << " seconds" << endl;
    cout << "You were running at speed " << speed << " km/h" << endl;

    return 0;
}