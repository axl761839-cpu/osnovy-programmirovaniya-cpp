﻿#include <iostream>
using namespace std;

int main()
{
    double money = 12.5;

    int dollars = (int)money;
    int cents = (int)((money - dollars) * 100);

    cout << dollars << " долларов и " << cents << " центов" << endl;

    return 0;
}