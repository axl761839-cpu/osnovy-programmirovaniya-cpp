﻿#include <iostream>
using namespace std;

int main()
{
    int days = 17;

    int weeks = days / 7;
    int remainingDays = days % 7;

    cout << weeks << " недели и " << remainingDays << " дня" << endl;

    return 0;
}