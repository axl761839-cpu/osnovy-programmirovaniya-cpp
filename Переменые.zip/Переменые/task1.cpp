﻿#include <iostream>
using namespace std;

int main()
{
    int seconds = 3675;

    int hours = seconds / 3600;
    int minutes = (seconds % 3600) / 60;
    int sec = seconds % 60;

    cout << "Часы: " << hours << endl;
    cout << "Минуты: " << minutes << endl;
    cout << "Секунды: " << sec << endl;

    return 0;
}