﻿#include <iostream>
using namespace std;

int main()
{
    double deposit = 1000;
    double annualPercent = 12;

    double monthlyPayment = deposit * annualPercent / 100 / 12;

    cout << "Сумма вклада: " << deposit << " евро" << endl;
    cout << "Процент годовых: " << annualPercent << "%" << endl;
    cout << "Выплата за месяц: " << monthlyPayment << " евро" << endl;

    return 0;
}