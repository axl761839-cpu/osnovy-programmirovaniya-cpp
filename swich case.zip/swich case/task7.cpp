#include <iostream>
#include <windows.h>

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    int number;

    std::cout << "Введите число от 1 до 10: ";
    std::cin >> number;

    switch (number) {
    case 1:
        std::cout << "I";
        break;
    case 2:
        std::cout << "II";
        break;
    case 3:
        std::cout << "III";
        break;
    case 4:
        std::cout << "IV";
        break;
    case 5:
        std::cout << "V";
        break;
    case 6:
        std::cout << "VI";
        break;
    case 7:
        std::cout << "VII";
        break;
    case 8:
        std::cout << "VIII";
        break;
    case 9:
        std::cout << "IX";
        break;
    case 10:
        std::cout << "X";
        break;
    default:
        std::cout << "Ошибка: число должно быть от 1 до 10";
    }

    return 0;
}