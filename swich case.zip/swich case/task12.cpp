#include <iostream>
#include <windows.h>

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    double meters;
    char unit;

    std::cout << "Введите количество метров: ";
    std::cin >> meters;

    std::cout << "Введите единицу (m/c/d/k/i/f): ";
    std::cin >> unit;

    switch (unit) {
        case 'm':
            std::cout << "Результат: " << meters << " м";
            break;

        case 'c':
            std::cout << "Результат: " << meters * 100 << " см";
            break;

        case 'd':
            std::cout << "Результат: " << meters * 10 << " дм";
            break;

        case 'k':
            std::cout << "Результат: " << meters / 1000 << " км";
            break;

        case 'i':
            std::cout << "Результат: " << meters * 39.3701 << " дюймов";
            break;

        case 'f':
            std::cout << "Результат: " << meters * 3.28084 << " футов";
            break;

        default:
            std::cout << "Ошибка: неизвестная единица измерения";
    }

    return 0;
}