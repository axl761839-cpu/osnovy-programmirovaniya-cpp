#include <iostream>
#include <windows.h>

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    int hour;

    std::cout << "Введите час (0-23): ";
    std::cin >> hour;

    switch (hour) {
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
        std::cout << "Ночь";
        break;

    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
    case 11:
        std::cout << "Утро";
        break;

    case 12:
    case 13:
    case 14:
    case 15:
    case 16:
    case 17:
        std::cout << "День";
        break;

    case 18:
    case 19:
    case 20:
    case 21:
    case 22:
    case 23:
        std::cout << "Вечер";
        break;

    default:
        std::cout << "Ошибка: некорректное время";
    }

    return 0;
}