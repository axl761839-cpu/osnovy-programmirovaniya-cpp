#include <iostream>
#include <windows.h>

enum Season {
    WINTER,
    SPRING,
    SUMMER,
    AUTUMN
};

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    int number;

    std::cout << "Введите номер сезона (0-3): ";
    std::cin >> number;

    Season season = static_cast<Season>(number);

    switch (season) {
    case WINTER:
        std::cout << "Зима, средняя температура -10°C";
        break;

    case SPRING:
        std::cout << "Весна, средняя температура +10°C";
        break;

    case SUMMER:
        std::cout << "Лето, средняя температура +25°C";
        break;

    case AUTUMN:
        std::cout << "Осень, средняя температура +10°C";
        break;

    default:
        std::cout << "Ошибка: такого сезона нет";
    }

    return 0;
}