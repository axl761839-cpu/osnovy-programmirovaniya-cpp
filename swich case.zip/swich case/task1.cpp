#include <iostream>
#include <windows.h>

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    double a, b;
    char op;

    std::cout << "Введите первое число: ";
    std::cin >> a;

    std::cout << "Введите оператор (+, -, *, /): ";
    std::cin >> op;

    std::cout << "Введите второе число: ";
    std::cin >> b;

    switch (op) {
    case '+':
        std::cout << "Результат: " << a + b;
        break;

    case '-':
        std::cout << "Результат: " << a - b;
        break;

    case '*':
        std::cout << "Результат: " << a * b;
        break;

    case '/':
        if (b == 0) {
            std::cout << "Ошибка: деление на ноль";
        }
        else {
            std::cout << "Результат: " << a / b;
        }
        break;

    default:
        std::cout << "Ошибка: неизвестный оператор";
    }

    return 0;
}