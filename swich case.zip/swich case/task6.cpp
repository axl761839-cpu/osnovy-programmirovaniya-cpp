#include <iostream>
#include <windows.h>

enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT
};

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    char symbol;

    std::cout << "Введите направление (w/s/a/d): ";
    std::cin >> symbol;

    Direction direction;

    switch (symbol) {
    case 'w':
        direction = UP;
        break;
    case 's':
        direction = DOWN;
        break;
    case 'a':
        direction = LEFT;
        break;
    case 'd':
        direction = RIGHT;
        break;
    default:
        std::cout << "Ошибка: неизвестное направление";
        return 0;
    }

    switch (direction) {
    case UP:
        std::cout << "Движение: (0, +1)";
        break;
    case DOWN:
        std::cout << "Движение: (0, -1)";
        break;
    case LEFT:
        std::cout << "Движение: (-1, 0)";
        break;
    case RIGHT:
        std::cout << "Движение: (+1, 0)";
        break;
    }

    return 0;
}