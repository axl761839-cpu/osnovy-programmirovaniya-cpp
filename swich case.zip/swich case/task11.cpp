#include <iostream>
#include <windows.h>

enum AccessLevel {
    GUEST,
    USER,
    MODERATOR,
    ADMIN
};

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    int number;

    std::cout << "Введите уровень доступа (0-3): ";
    std::cin >> number;

    AccessLevel level = static_cast<AccessLevel>(number);

    switch (level) {
        case GUEST:
            std::cout << "Гость\n";
            std::cout << "Разрешено: просмотр главной страницы\n";
            std::cout << "Разрешено: просмотр открытых материалов";
            break;

        case USER:
            std::cout << "Пользователь\n";
            std::cout << "Разрешено: просмотр материалов\n";
            std::cout << "Разрешено: создание комментариев";
            break;

        case MODERATOR:
            std::cout << "Модератор\n";
            std::cout << "Разрешено: удаление комментариев\n";
            std::cout << "Разрешено: блокировка пользователей";
            break;

        case ADMIN:
            std::cout << "Администратор\n";
            std::cout << "Разрешено: управление пользователями\n";
            std::cout << "Разрешено: изменение настроек системы";
            break;

        default:
            std::cout << "Ошибка: неизвестный уровень доступа";
    }

    return 0;
}