#include <iostream>
#include <windows.h>
#include <cctype>

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    char color;

    std::cout << "Введите цвет светофора (r/y/g): ";
    std::cin >> color;

    switch (std::tolower(color)) {
        case 'r':
            std::cout << "Стоп";
            break;

        case 'y':
            std::cout << "Приготовиться";
            break;

        case 'g':
            std::cout << "Можно идти";
            break;

        default:
            std::cout << "Ошибка: неизвестный цвет";
    }

    return 0;
}