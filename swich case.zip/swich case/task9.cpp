#include <iostream>
#include <windows.h>

enum OrderStatus {
    NEW,
    PAID,
    SHIPPED,
    DELIVERED,
    CANCELLED
};

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    int number;

    std::cout << "Введите статус заказа (0-4): ";
    std::cin >> number;

    OrderStatus status = static_cast<OrderStatus>(number);

    switch (status) {
        case NEW:
            std::cout << "Новый заказ";
            break;

        case PAID:
            std::cout << "Заказ оплачен";
            break;

        case SHIPPED:
            std::cout << "Заказ отправлен";
            break;

        case DELIVERED:
            std::cout << "Заказ доставлен";
            break;

        case CANCELLED:
            std::cout << "Заказ отменён";
            break;

        default:
            std::cout << "Ошибка: неизвестный статус";
    }

    return 0;
}