﻿#include <iostream>

int main()
{
    double rate, hours, bonus;
    std::cin >> rate >> hours >> bonus;

    const double TAX = 0.13;

    double salary = rate * hours + bonus;
    double tax = salary * TAX;
    double netSalary = salary - tax;

    std::cout << "Начислено: " << salary << std::endl;
    std::cout << "Налог: " << tax << std::endl;
    std::cout << "На руки: " << netSalary << std::endl;

    return 0;
}