﻿#include <iostream>

int main()
{
    int n;
    std::cin >> n;

    int a = n / 1000;
    int b = (n / 100) % 10;
    int c = (n / 10) % 10;
    int d = n % 10;

    int sum = a + b + c + d;
    int product = a * b * c * d;

    std::cout << "Сумма: " << sum << std::endl;
    std::cout << "Произведение: " << product << std::endl;

    return 0;
}