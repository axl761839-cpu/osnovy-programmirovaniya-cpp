﻿#include <iostream>

int main()
{
    double a, b;
    std::cin >> a >> b;

    double P = 2 * (a + b);
    double S = a * b;

    std::cout << "Периметр: " << P << std::endl;
    std::cout << "Площадь: " << S << std::endl;

    return 0;
}