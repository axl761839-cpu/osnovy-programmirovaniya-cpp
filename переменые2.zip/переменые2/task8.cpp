﻿#include <iostream>

int main()
{
    double r;
    std::cin >> r;

    const double PI = 3.14159;

    double L = 2 * PI * r;
    double S = PI * r * r;

    std::cout << "Длина: " << L << std::endl;
    std::cout << "Площадь: " << S << std::endl;

    return 0;
}