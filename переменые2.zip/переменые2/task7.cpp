﻿#include <iostream>

int main()
{
    double C;
    std::cin >> C;

    const double NINE = 9;
    const double FIVE = 5;

    double F = C * NINE / FIVE + 32;

    std::cout << F;

    return 0;
}