﻿#include <iostream>

int main()
{
    double a, b, c;
    std::cin >> a >> b >> c;

    double average = (a + b + c) / 3.0;

    std::cout << average;

    return 0;
}